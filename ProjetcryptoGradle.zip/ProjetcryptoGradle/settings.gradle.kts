rootProject.name = "ProjetcryptoGradle"

